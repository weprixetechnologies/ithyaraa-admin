import React from 'react'
import Layout from 'src/layout'

const VendorDetails = () => {
    return (
        <Layout active={'vendors-users-add'} title={'Vendor Details'}>

        </Layout>
    )
}

export default VendorDetails