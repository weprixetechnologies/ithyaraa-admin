import React, { useEffect, useState, useCallback } from 'react';
import { getPaginatedProducts, getProductCount } from './../../lib/api/productsApi';
import InputUi from '@/components/ui/inputui';

const SelectProducts = ({
    onProductToggle,
    initialSelected = [],
    initialFilters = {
        name: '',
        productID: '',
        categoryID: '',
        categoryName: '',
        type: ''
    }
}) => {
    const [state, setSelected] = useState({
        filters: initialFilters,
        appliedFilters: { ...initialFilters }, // ✅ prefill so first fetch uses initial filters
        productsByPage: {},
        page: 1,
        selectedProductIDs: initialSelected,
        loading: false,
        totalPages: 1,
    });

    const {
        filters,
        appliedFilters,
        productsByPage,
        page,
        selectedProductIDs,
        loading,
        totalPages
    } = state;

    const limit = 10;

    // Update filter values
    const handleFilterChange = useCallback((key, value) => {
        setSelected(prev => ({
            ...prev,
            filters: {
                ...prev.filters,
                [key]: value
            }
        }));
    }, []);

    // Apply current filters
    const applyFilters = useCallback(() => {
        setSelected(prev => ({
            ...prev,
            appliedFilters: { ...prev.filters },
            productsByPage: {},
            page: 1
        }));
    }, []);

    // Fetch products for a specific page
    const fetchProducts = useCallback(async (pageToFetch) => {
        const pageKey = `page-${pageToFetch}`;
        if (productsByPage[pageKey]) return;

        setSelected(prev => ({ ...prev, loading: true }));

        try {
            const result = await getPaginatedProducts({
                page: pageToFetch,
                limit,
                filters: {
                    name: appliedFilters.name?.trim() || undefined,
                    productID: appliedFilters.productID?.trim() || undefined,
                    categoryID: appliedFilters.categoryID?.trim() || undefined,
                    categoryName: appliedFilters.categoryName?.trim() || undefined,
                    type: appliedFilters.type?.trim() || undefined
                },
            });

            const { totalItems } = await getProductCount(appliedFilters); // ✅ use appliedFilters for accurate count

            const parsedProducts = result.data.map(product => ({
                ...product,
                featuredImage: JSON.parse(product.featuredImage || '[]'),
            }));

            const calculatedTotalPages = Math.ceil(totalItems / limit) || 1;

            setSelected(prev => ({
                ...prev,
                productsByPage: {
                    ...prev.productsByPage,
                    [pageKey]: parsedProducts,
                },
                totalPages: calculatedTotalPages,
                loading: false,
            }));
        } catch (error) {
            console.error('Error fetching products:', error);
            setSelected(prev => ({ ...prev, loading: false }));
        }
    }, [appliedFilters, productsByPage]);

    // Toggle selection
    const toggleProductSelection = (productID) => {
        setSelected(prev => {
            const isSelected = prev.selectedProductIDs.includes(productID);
            const newSelected = isSelected
                ? prev.selectedProductIDs.filter(id => id !== productID)
                : [...prev.selectedProductIDs, productID];

            return { ...prev, selectedProductIDs: newSelected };
        });

        onProductToggle(productID);
    };

    // Fetch products when page or filters change
    useEffect(() => {
        fetchProducts(page);
    }, [page, appliedFilters, fetchProducts]);

    const currentProducts = productsByPage[`page-${page}`] || [];

    return (
        <div className="flex flex-col gap-4 p-4">
            {/* Filters */}
            <div className="grid grid-cols-2 gap-4">
                <InputUi
                    label="Filter by Name"
                    datafunction={(val) => handleFilterChange('name', val.target.value)}
                    value={filters.name}
                />
                <InputUi
                    label="Filter by Product ID"
                    datafunction={(val) => handleFilterChange('productID', val.target.value)}
                    value={filters.productID}
                />
                <InputUi
                    label="Filter by Category Name"
                    datafunction={(val) => handleFilterChange('categoryName', val.target.value)}
                    value={filters.categoryName}
                />
                <InputUi
                    label="Filter by Category ID"
                    type="number"
                    datafunction={(val) => handleFilterChange('categoryID', val.target.value)}
                    value={filters.categoryID}
                />
            </div>

            <div className="flex justify-end">
                <button
                    onClick={applyFilters}
                    className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
                >
                    Search
                </button>
            </div>

            {/* Products */}
            {loading ? (
                <div className="flex justify-center items-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {currentProducts.length === 0 ? (
                        <div className="col-span-full text-center py-8 text-gray-500">
                            {Object.keys(appliedFilters).some(key => appliedFilters[key])
                                ? "No products match your filters"
                                : "No products available"}
                        </div>
                    ) : (
                        currentProducts.map(product => {
                            const isSelected = selectedProductIDs.includes(product.productID);
                            return (
                                <ProductCard
                                    key={product.productID}
                                    product={product}
                                    isSelected={isSelected}
                                    onToggle={toggleProductSelection}
                                />
                            );
                        })
                    )}
                </div>
            )}

            {/* Pagination */}
            <PaginationControls
                currentPage={page}
                totalPages={totalPages}
                onPageChange={(newPage) => setSelected(prev => ({ ...prev, page: newPage }))}
            />

            {/* Selected Summary */}
            {selectedProductIDs.length > 0 && (
                <div className="mt-4 p-3 bg-gray-50 rounded text-sm">
                    <strong>Selected Products:</strong> {selectedProductIDs.length} items
                    <div className="mt-1 text-xs text-gray-600 truncate">
                        IDs: {selectedProductIDs.join(', ')}
                    </div>
                </div>
            )}
        </div>
    );
};

const ProductCard = ({ product, isSelected, onToggle }) => (
    <label
        onClick={() => onToggle(product.productID)}
        className={`relative cursor-pointer flex flex-col p-3 gap-2 border rounded-lg overflow-hidden transition-all duration-200 ${isSelected
                ? 'border-green-500 ring-2 ring-green-200'
                : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
            }`}
    >
        {isSelected && (
            <div className="absolute inset-0 bg-green-500 bg-opacity-20 z-10 flex items-center justify-center">
                <div className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                    Selected
                </div>
            </div>
        )}
        <div className="aspect-square bg-gray-100 rounded overflow-hidden">
            <img
                src={product.featuredImage?.[0]?.imgUrl || '/placeholder.png'}
                alt={product.name}
                className="w-full h-full object-cover"
                loading="lazy"
            />
        </div>
        <div className="mt-2">
            <div className="font-medium text-gray-900 line-clamp-1">{product.name}</div>
            <div className="text-xs text-gray-500">ID: {product.productID}</div>
        </div>
    </label>
);

const PaginationControls = ({ currentPage, totalPages, onPageChange }) => {
    const canGoPrev = currentPage > 1;
    const canGoNext = currentPage < totalPages;

    return (
        <div className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6">
            <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
                <p className="text-sm text-gray-700">
                    Showing page <span className="font-medium">{currentPage}</span> of{' '}
                    <span className="font-medium">{totalPages}</span>
                </p>
                <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
                    <button
                        onClick={() => canGoPrev && onPageChange(currentPage - 1)}
                        disabled={!canGoPrev}
                        className={`relative inline-flex items-center rounded-l-md px-2 py-2 ring-1 ring-inset ring-gray-300 ${!canGoPrev ? 'cursor-not-allowed opacity-50' : ''
                            }`}
                    >
                        Prev
                    </button>
                    <button
                        aria-current="page"
                        className="relative z-10 inline-flex items-center bg-blue-500 px-4 py-2 text-sm font-semibold text-white"
                    >
                        {currentPage}
                    </button>
                    <button
                        onClick={() => canGoNext && onPageChange(currentPage + 1)}
                        disabled={!canGoNext}
                        className={`relative inline-flex items-center rounded-r-md px-2 py-2 ring-1 ring-inset ring-gray-300 ${!canGoNext ? 'cursor-not-allowed opacity-50' : ''
                            }`}
                    >
                        Next
                    </button>
                </nav>
            </div>
        </div>
    );
};

export default React.memo(SelectProducts);
